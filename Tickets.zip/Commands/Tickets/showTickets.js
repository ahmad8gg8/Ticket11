const { MessageEmbed } = require('discord.js');
const db = require('pro.db');
const config = require(`${process.cwd()}/config`);

module.exports = {
    name: "showtickets",
    description: "Show all open tickets",
    run: async (client, message) => {
        // Check if the user has the necessary permissions
        if (!message.member.permissions.has('ADMINISTRATOR') && !config.owners.includes(message.author.id)) {
            return message.reply("**ليس لديك الأذونات اللازمة لعرض التذاكر.** 🚫");
        }

        const ticketCount = await db.get(`ticketCount_${message.guild.id}`) || 0;

        // إنشاء Embed لعرض عدد التذاكر
        const embed = new MessageEmbed()
            .setColor('#5c5e64') // يمكنك تغيير اللون
            .setTitle('عددالتكتات ')
            .setDescription(`**عدد التكتات في السيرفر: ${ticketCount}**`)
            .setThumbnail(`https://cdn.discordapp.com/attachments/1311419906264403989/1313581938069471242/info-.png?ex=6750a803&is=674f5683&hm=2852b4f2581fedf8a0aef6d5a11a63c2f26524539a1b3bde366dda990531f58b&`)
            .setFooter({ text: 'Destiny Store', iconURL: 'https://cdn.discordapp.com/attachments/1312023087939719219/1313589020567273512/emo.png?ex=6751575b&is=675005db&hm=cff8d67f1f5b781c88781a011d22d840c694c90a00d2d862e68cc200171dfd62&' });

        // إرسال الإطار المضمّن
        message.channel.send({ embeds: [embed] });
    }
};
