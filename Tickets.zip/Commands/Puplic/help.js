const Discord = require("discord.js");
const db = require(`pro.db`);
const { MessageEmbed } = require("discord.js");
const { prefix, owners } = require(`${process.cwd()}/config`);

module.exports = {
    name: 'help', // هنا اسم الامر
    run: async (client, message, args) => {
        
        if (!owners.includes(message.author.id)) return message.react('❌');
        
        const isEnabled = db.get(`command_enabled_${module.exports.name}`);
        if (isEnabled === false) {
            return; 
        }

        const Color = db.get(`Guild_Color_${message.guild.id}`) || '#5c5e64';

        const replyEmbed = new MessageEmbed()
            .setColor(Color)
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .setDescription(`**أوامر التذكرة:**
                **${prefix}settings**: جميع اوامر التحكم بالتكت
                **${prefix}setticket**:  رسالة التكت
                **${prefix}tcbrole**: اضافة رول بلوك
                **${prefix}blocklist**: روئيه قائمه البلاك ليست
                **${prefix}block**: اعطاء عضو بلوك
                **${prefix}rename**: تعيين إسم جديد لتذكرة
                **${prefix}close**: إغلاق التذكرة
                **${prefix}points**: رؤية نقاط الادارة
                **${prefix}top**: رؤية توب نقاط 
                **${prefix}add**:اضافة نقاط او ازاله من الاداري
                **${prefix}rstpoint**: تصفير نقاط عضو معين
                **${prefix}rstlpoints**: تصفير جميع النقاط 
            `)
            .setFooter({ text: 'Destiny Store', iconURL: 'https://media.discordapp.net/attachments/1312023087939719219/1313589020567273512/emo.png?ex=6751575b&is=675005db&hm=cff8d67f1f5b781c88781a011d22d840c694c90a00d2d862e68cc200171dfd62&=&format=webp&quality=lossless&width=160&height=160' })
            .setThumbnail('https://cdn.discordapp.com/attachments/1311419906264403989/1313581938069471242/info-.png?ex=6750a803&is=674f5683&hm=2852b4f2581fedf8a0aef6d5a11a63c2f26524539a1b3bde366dda990531f58b&');

        message.reply({ embeds: [replyEmbed] }).catch(console.error);
    }
}
